package com.clipshelf.app

fun main() {
    val tests = mutableListOf<Pair<String, () -> Unit>>()
    fun test(name: String, action: () -> Unit) { tests += name to action }
    test("capped video cannot exceed cap") { check(Rules.selector(Choice(maxHeight = 720)) == "bestvideo[height<=720]+bestaudio/best[height<=720]") }
    test("best available video") { check(Rules.selector(Choice(maxHeight = null)) == "bestvideo+bestaudio/best") }
    test("exact video and audio") { check(Rules.selector(Choice(videoId = "137", audioId = "251")) == "137+251") }
    test("combined stream") { check(Rules.selector(Choice(videoId = "18", combined = true)) == "18") }
    test("exact video and best audio") { check(Rules.selector(Choice(videoId = "248")) == "248+bestaudio") }
    test("automatic video with exact audio no fallback") { check(Rules.selector(Choice(maxHeight = 480, audioId = "140")) == "bestvideo[height<=480]+140") }
    test("audio source selection") { check(Rules.selector(Choice(mode = Mode.AUDIO, audioId = "251")) == "251") }
    test("mp3 settings") { val o = Rules.formatOptions(Choice(mode = Mode.AUDIO, audioType = AudioType.MP3, mp3Quality = "320K")); check("--audio-format" to "mp3" in o); check("--audio-quality" to "320K" in o) }
    test("exact original audio no conversion") { val o = Rules.formatOptions(Choice(mode = Mode.AUDIO, audioId = "140")); check(o == listOf("-f" to "140")) }
    test("audio fallback is extracted") { check("--extract-audio" to null in Rules.formatOptions(Choice(mode = Mode.AUDIO))) }
    test("unsafe selector rejected") { check(runCatching { Rules.selector(Choice(videoId = "a/b")) }.isFailure) }
    test("playlist folder") { check(Rules.folder("C++ / Basics", true) == "Download/Nazzelha/C++ _ Basics/") }
    test("single folder") { check(Rules.folder("test", false) == "Download/Nazzelha/") }
    test("ordered names") { val j = Job(Clip(7, "abc", "First/Lesson", "https://youtu.be/abcdef12345"), Choice(), "Download/Nazzelha/Course/", true); check(Rules.fileName(j, "mp4") == "007 - First_Lesson [abc].mp4") }
    test("UTF8 filenames") { val name = Rules.safeName("دورة".repeat(100), "Playlist", 100); check(name.toByteArray().size <= 100); check(name.isNotBlank()) }
    test("path traversal folder") { check(Rules.safeName("..", "Playlist") == "Playlist"); check('/' !in Rules.safeName("../secret", "Playlist")) }
    test("link parsing") { check(Rules.youtubeLink("watch https://youtu.be/abc123?si=abc") == "https://youtu.be/abc123?si=abc"); check(Rules.youtubeLink("https://youtube.com.bad.site/watch?v=test") == null); check(Rules.youtubeLink("https://evil@youtube.com/watch?v=test") == null) }
    test("choice summary") { check(Choice(videoId = "18", combined = true).summary().contains("Combined audio")); check(Choice(mode = Mode.AUDIO, audioType = AudioType.MP3).summary().contains("192K")) }
    test("duration") { check(Rules.duration(3661) == "1:01:01") }
    test("unknown download progress is not a made-up percentage") { check(TransferProgress.fromCallback(-1f, -1, "Connecting") == null) }
    test("stream percentage and ETA") { val p = TransferProgress.fromCallback(64.4f, 21, "[download]")!!; check(p.phase == Phase.DOWNLOADING && p.percent == 64 && p.metrics?.etaLabel() == "21s") }
    test("extract live rate, size and ETA") { val u = TransferProgress.fromCallback(68.2f, 42, "[download] 68.2% of 48.00MiB at 2.30MiB/s ETA 00:07")!!; check(u.metrics == TransferMetrics("2.30MiB/s", 7, "48.00MiB")) }
    test("approximate size and hours ETA") { val u = TransferProgress.fromCallback(3f, -1, "[download] 3.0% of ~ 1.20GiB at 800.12KiB/s ETA 01:15:23")!!; check(u.metrics?.total == "~ 1.20GiB" && u.metrics?.etaLabel() == "1h 15m") }
    test("unknown speed and time remain unknown") { val u = TransferProgress.fromCallback(0f, -1, "[download] 0.0% of Unknown at Unknown B/s ETA Unknown")!!; check(u.metrics == TransferMetrics()) }
    test("minutes and seconds formatting") { check(TransferMetrics(etaSeconds = 125).etaLabel() == "2m 05s") }
    test("processing and saving have no network metrics") { check(TransferProgress.fromCallback(100f, 0, "[Merger] Merging formats")?.metrics == null); check(TransferProgress.saving(20, 100).metrics == null) }
    test("stream completion does not mark file saved") { val p = TransferProgress.fromCallback(100f, 0, "[download]")!!; check(p.percent == null && p.phase == Phase.DOWNLOADING) }
    test("FFmpeg progress is indeterminate") { val p = TransferProgress.fromCallback(100f, 0, "[Merger] Merging formats")!!; check(p.phase == Phase.PROCESSING && p.percent == null) }
    test("save progress follows copied bytes and waits for finalization") { check(TransferProgress.saving(50, 100).percent == 50); check(TransferProgress.saving(100, 100).percent == 99); check(TransferProgress.saving(0, 0).percent == null) }
    test("batch counts only terminal states") { val j = Job(Clip(1,"abc","Video","https://youtu.be/abcdef12345"),Choice(),"Download/",false); check(TransferProgress.processed(Phase.entries.map { JobState(j,it) }) == 3) }
    fun lum(c: Int): Double {
        fun channel(shift: Int): Double { val x = ((c shr shift) and 255) / 255.0; return if (x <= 0.04045) x / 12.92 else Math.pow((x + 0.055) / 1.055, 2.4) }
        return 0.2126 * channel(16) + 0.7152 * channel(8) + 0.0722 * channel(0)
    }
    fun contrast(a: Int, b: Int): Double = (maxOf(lum(a),lum(b))+0.05)/(minOf(lum(a),lum(b))+0.05)
    for ((name,p) in listOf("dark" to NazzelhaColors.dark, "light" to NazzelhaColors.light)) {
        test("$name primary and progress contrast") { check(contrast(p.accent,p.onAccent)>=4.5); check(contrast(p.accent,p.panel2)>=3.0) }
        test("$name text and status contrast") { for (bg in listOf(p.background,p.panel,p.panel2)) for (fg in listOf(p.ink,p.soft,p.green,p.red,p.accent)) check(contrast(fg,bg)>=4.5) { "Insufficient contrast $name $fg / $bg" } }
    }
    val mb = 1024L * 1024
    fun video(id: String, h: Int, bytes: Long, audio: Boolean = false) = Stream(id, "mp4", h * 16 / 9, h, 30, "avc1", if (audio) "mp4a" else "none", 1000.0, bytes, "")
    fun audio(id: String, bytes: Long, br: Double, approx: Boolean = false) = Stream(id, "m4a", 0, 0, 0, "none", "mp4a", br, bytes, "", approx, br, br)
    val a1 = audio("140", 4*mb, 96.0); val a2 = audio("141", 8*mb, 160.0)
    val v720 = video("136", 720, 80*mb); val v1080 = video("137", 1080, 120*mb)
    val c = Clip(1, "abcdefghijk", "Video", "https://youtu.be/abcdefghijk", 600, streams = listOf(a1,a2,v720,v1080))
    test("automatic video quality pins best audio and selected video ID") {
        val p = MediaPlanner.plan(c, Choice(maxHeight = 1080))!!
        check(Rules.selector(p.choice) == "137+141"); check(p.video == v1080 && p.audio == a2); check(p.output.bytes == 128*mb && p.output.approximate); check(p.transfer == SizeEstimate(128*mb,false))
    }
    test("quality change immediately changes both estimates without fetching") {
        val high = MediaPlanner.plan(c, Choice(maxHeight = 1080))!!; val low = MediaPlanner.plan(c, Choice(maxHeight = 720))!!
        check(low.output.bytes == 88*mb && high.output.bytes == 128*mb); check(Rules.selector(low.choice) == "136+141")
    }
    test("height cap never silently exceeds user selection") { check(MediaPlanner.plan(c, Choice(maxHeight = 480)) == null) }
    test("best source follows yt-dlp ordering rather than just bitrate") {
        val preferred = audio("pref", 3*mb, 80.0)
        val p = MediaPlanner.plan(c.copy(streams=listOf(a1,a2,preferred,v720,v1080)),Choice())!!; check(p.audio?.id == "pref")
    }
    test("explicit audio selection retained for advanced mode") { check(Rules.selector(MediaPlanner.plan(c, Choice(audioId="140"))!!.choice) == "137+140") }
    test("combined video never double counts audio") { val combined = video("18", 720, 55*mb, true); val p = MediaPlanner.plan(c.copy(streams=listOf(combined)),Choice())!!; check(p.output.bytes == 55*mb && p.transfer.bytes == 55*mb && Rules.selector(p.choice)=="18") }
    test("combined-only highest resolution fallback is not replaced by lower resolution") { val combined=video("22",1080,90*mb,true); val p=MediaPlanner.plan(c.copy(streams=listOf(a1,a2,v720,combined)), Choice())!!; check(p.video==combined && p.audio==null) }
    test("audio-only original uses selected stream and exact input size") { val p=MediaPlanner.plan(c,Choice(mode=Mode.AUDIO,audioId="140"))!!; check(p.output.bytes==4*mb && p.transfer==p.output && Rules.selector(p.choice)=="140") }
    test("MP3 bitrate controls output estimate, not source download bytes") { val p=MediaPlanner.plan(c,Choice(mode=Mode.AUDIO,audioType=AudioType.MP3,mp3Quality="128K"))!!; check(p.output.bytes==9_600_000L && p.output.approximate && p.transfer.bytes==8*mb); val hi=MediaPlanner.plan(c,Choice(mode=Mode.AUDIO,audioType=AudioType.MP3,mp3Quality="320K"))!!; check(hi.output.bytes==24_000_000L && hi.transfer==p.transfer) }
    test("audio extraction from combined source never downloads a video as final audio") { val p=MediaPlanner.plan(c.copy(streams=listOf(video("18",360,20*mb,true).copy(audioBitrate=96.0))),Choice(mode=Mode.AUDIO))!!; check(p.choice.audioFromVideo && "--extract-audio" to null in Rules.formatOptions(p.choice) && p.output.bytes==7_200_000L && p.transfer.bytes==20*mb) }
    test("unknown duration and stream size stay unknown") { val p=MediaPlanner.plan(c.copy(duration=0,streams=listOf(a2.copy(size=0),v720.copy(size=0))),Choice())!!; check(p.output.bytes==null && p.transfer.bytes==null) }
    test("approximate metadata remains approximate") { val p=MediaPlanner.plan(c.copy(streams=listOf(a2.copy(sizeApprox=true),v720)),Choice())!!; check(p.transfer.approximate && p.transfer.bytes==88*mb) }
    test("bitrate fallback uses decimal kilobits and seconds") { check(MediaSizes.byRate(128.0,600).bytes==9_600_000L); check(MediaSizes.byRate(0.0,600).bytes==null); check(MediaSizes.byRate(Double.NaN,600).bytes==null) }
    test("unknown lossless conversion is not falsely exact") { val p=MediaPlanner.plan(c,Choice(mode=Mode.AUDIO,audioType=AudioType.FLAC))!!; check(p.output.bytes==null && p.transfer.bytes==8*mb) }
    test("selected totals count unknowns and exclude unselected") { val t=MediaSizes.total(listOf(SizeEstimate(12*mb,false),SizeEstimate(),SizeEstimate(4*mb,true))); check(t.knownBytes==16*mb && t.unknown==1 && t.count==3 && t.label().contains("1 unknown")); check(MediaSizes.total(emptyList()).label()=="0 B") }
    test("totals protect long overflow") { check(MediaSizes.total(listOf(SizeEstimate(Long.MAX_VALUE,false),SizeEstimate(1,false))).knownBytes==Long.MAX_VALUE) }
    test("plan cache reuses unchanged choice and invalidates when formats change") { val cache=PlanCache(); val a=cache.get(c,Choice()); check(cache.get(c,Choice())===a); check(cache.get(c,Choice(maxHeight=720))?.output?.bytes==88*mb); check(cache.get(c.copy(streams=emptyList()),Choice())==null) }
    test("thumbnails pick lightweight source near 320px") { val urls=listOf("https://i.ytimg.com/a.jpg" to 1280,"https://i.ytimg.com/b.jpg" to 320,"https://i.ytimg.com/c.jpg" to 120); check(ThumbnailRules.pick(c.id,urls,"")==urls[1].first) }
    test("thumbnail fallback uses only valid video ID and HTTPS") { check(ThumbnailRules.fallback(c.id)=="https://i.ytimg.com/vi/abcdefghijk/mqdefault.jpg"); check(ThumbnailRules.fallback("../evil").isEmpty()); check(!ThumbnailRules.valid("https://ytimg.com.evil.example/x")); check(!ThumbnailRules.valid("http://i.ytimg.com/x")); check(!ThumbnailRules.valid("https://evil@i.ytimg.com/x")) }
    test("missing thumbnail metadata is safe") { check(ThumbnailRules.pick(c.id,emptyList(),"")==ThumbnailRules.fallback(c.id)) }
    tests.forEach { (name, action) -> action(); println("PASS $name") }
    println("${tests.size} checks passed")
}
