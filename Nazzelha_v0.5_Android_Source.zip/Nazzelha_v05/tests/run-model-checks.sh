#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
kotlinc app/src/main/java/com/clipshelf/app/Model.kt app/src/main/java/com/clipshelf/app/MediaPlan.kt app/src/main/java/com/clipshelf/app/Palette.kt tests/ModelCheck.kt -include-runtime -d "$work/model.jar"
java -jar "$work/model.jar"
