# Nazzelha — Android downloader

A native Android/Kotlin prototype for downloading YouTube videos and playlists using yt-dlp, FFmpeg and the bundled QuickJS runtime. It does not require a personal backend. Only save media that you own, that is licensed for download, or that you have permission to download. Follow applicable platform terms and copyright law.

## Quick start / التشغيل

- Android 10+ (API 29), **arm64-v8a** only for this build. Android Studio with JDK 17, Android SDK 35, Gradle 8.10.2, and internet access are needed to compile.
- In Android Studio, open this directory as a Gradle project. Use Gradle 8.10.2 and JDK 17. Install SDK Platform 35 and Build Tools 35.0.0 if prompted. Sync and run `:app:assembleDebug`, or use Run on your device.
- From a terminal with Gradle 8.10.2 installed: `gradle :app:assembleDebug`. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`. This archive intentionally does not include a Gradle wrapper JAR, the Android SDK, or third-party binaries.
- Optional: with ADB and USB debugging enabled: `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

### Build an APK on GitHub without Android Studio

This repository includes `.github/workflows/android.yml`. Create a repository and push the complete extracted directory, including hidden files. For example, after creating an empty repository:

```sh
git init
git add .
git commit -m "Add Nazzelha Android project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Open Actions > Build Android APK > latest run. If successful, download the `Nazzelha-arm64-debug` artifact and extract the APK. The workflow is also manually runnable. This workflow is supplied but has not been executed in the authoring environment. Android may prompt you to allow installation from the app used to open the APK. A debug APK is for personal testing, not a production release.

## How to use

1. Open the app. Tap **Update** to update the embedded yt-dlp to its current stable release before testing. The initial wrapper release may contain an old yt-dlp executable.
2. Paste a YouTube video or playlist URL, or use YouTube's Share action to send a link to Nazzelha. Turn off **Include playlist** for a video URL that also contains a playlist.
3. Press **Load link**. A playlist is loaded using flat metadata first. Titles, thumbnail images, durations and selection boxes appear before the detailed format lookups finish. The app then inspects formats progressively with two workers.
4. Use **All** / **None**, then select the individual videos to download.
5. **Batch quality** sets the default quality and mode. Choose whether to replace the selected videos' existing overrides. Available video limits: Best, 4320p, 2160p, 1440p, 1080p, 720p, 480p, 360p, 240p, 144p. A limit means at or below the requested resolution, not guaranteed exact resolution. The default is 1080p.
6. Tap **Quality** on an individual video to change its settings. The app reads detailed formats in the background; tapping an item that is still loading prioritizes it. Tap **Exact formats** for advanced stream selection. Choose an exact video format and a separate exact audio format, or let yt-dlp choose. A combined stream has its own audio, so separate audio selection is hidden in that case. Stream descriptions include format ID, codec, resolution, FPS, bitrate or estimated size when available. Exact format selection will fail rather than silently substitute another format if it disappears.
7. Audio-only mode offers original audio where possible, MP3, M4A, Opus, and FLAC. MP3 output bitrate can be set to 64/96/128/192/256/320 kbps. Conversion does not improve source quality. Video + audio streams are merged to compatible MP4 or MKV when required; a pre-combined source can retain its native container.
8. Press **Download selected**, confirm, and open **Downloads** to monitor each item. Jobs are processed sequentially using a foreground service with progress and a cancel-batch action. Per-stream progress can reset when a separate audio stream begins. Completed files can be opened from this screen or the device's Files app.

## Storage

The app uses Android MediaStore Downloads (no broad storage permission). The temporary download and FFmpeg processing happen in app cache, then the finished media is copied to shared Downloads. Have enough free storage for both the temporary files and the final output. For playlist `C++ Fundamentals`:

```text
Download/
  Nazzelha/
    C++ Fundamentals/
      001 - Introduction [videoId].mp4
      003 - Loops [videoId].mp3
      005 - Functions [videoId].mkv
```

The prefix is the original playlist position, not the position in your selected subset. A standalone video is saved directly in `Download/Nazzelha/`. Invalid filename characters are sanitized and names are UTF-8 byte limited; the OS may append suffixes when a filename already exists.

## Implementation

- `Model.kt`: pure Kotlin models, format selector construction, validation, safe path and filename logic.
- `Engine.kt`: playlist metadata via `--flat-playlist --dump-single-json`, exact per-video metadata, yt-dlp download and update, FFmpeg conversion, MediaStore publication.
- `DownloadService.kt`: sequential foreground download queue with notifications, progress, cancellation and per-item errors.
- `MainActivity.kt`: light and dark native UI, progressive format loading, recycled rows, thumbnail caching via Coil 2.7.0, dynamic output/transfer totals, batch and per-video settings, queue view.
- `MediaPlan.kt`: pure Kotlin planner, pinned format IDs, exact and estimated size arithmetic, thumbnail rules, in-memory plan cache.

Dependencies are pinned to youtubedl-android 0.18.1, which includes QuickJS for current YouTube extractor requirements. The engine enables official yt-dlp EJS script retrieval from GitHub when needed. No accounts, cookies, private APIs, analytics or custom backend are included. Media URL extraction and downloads contact YouTube and may contact GitHub for official extractor updates/scripts.

## Verification and limits

- The 54 pure Kotlin logic, palette, media planning, size and thumbnail checks in `tests/ModelCheck.kt` were compiled and executed successfully with the installed Kotlin compiler; run `./tests/run-model-checks.sh` with `kotlinc` and Java available.
- The Android app itself has **not** been compiled, installed, or tested against live YouTube in the authoring environment: Android SDK/Gradle were not installed and external dependency downloads were unavailable. The GitHub workflow and instructions provide a reproducible build path, not a verified APK.
- The selected wrapper bundles native executables. Upstream has reported compatibility issues on some devices with 16 KB memory pages (particularly FFmpeg); confirm on target hardware. YouTube can change its extraction behavior or return 403/limited formats even with QuickJS; Update is not a guarantee. Only actual returned formats can be selected. No guarantee for 4K/8K on any given video.
- This is an initial version: selection/queue state is in memory (survives switching screens and ordinary backgrounding but not process death or reboot), and cancellation removes temporary files; no automatic resume, persistent download history, sign-in, restricted/private content, or custom download-directory picker. Android foreground-service time limits and device battery policies still apply. Live/inaccessible/private/DRM streams are not supported.
- Before distributing: build and test on a physical Android device, verify mixed playlist output, cancellation, no-network errors and 16 KB native libraries; sign a release build and review dependency licenses/security.

## Manual device QA checklist

- Single video: inspect available streams, select a 720p or other returned format, merge audio and verify playback.
- Mixed playlist: select nonconsecutive videos; set different video limits or exact streams; set one item to audio-only MP3 and one to original audio. Check folder title and original order prefixes.
- Switch tabs during download and background the app; check notification progress and queue status. Cancel batch and verify no unfinished file is published.
- Try a removed/private video, a network failure, an invalid URL, and duplicate downloads; check errors and no crash.
- Confirm output files are visible in Android Files and accessible after restarting the app. Test on 16 KB page size hardware if relevant.

## Upstream references

- https://github.com/yausername/youtubedl-android (GPL-3.0, Android wrapper)
- https://github.com/yausername/youtubedl-android/releases/tag/0.18.1 (QuickJS)
- https://github.com/yt-dlp/yt-dlp (extractor and CLI options)
- https://github.com/yt-dlp/yt-dlp/wiki/EJS (JavaScript runtime and scripts)
- https://developer.android.com/training/data-storage/shared/media (MediaStore)

Project source: GPL-3.0-or-later. Third-party components remain under their respective licenses; review all notices and corresponding source obligations when distributing a built binary. No third-party binary or font is included in this source archive.

## Progress and loading (v0.2)
- Link metadata and format inspection use indeterminate progress indicators.
- Download percentages and ETA are reported by yt-dlp for the current stream, not estimated whole-file progress. Separate audio and video streams may reset the transfer progress.
- FFmpeg processing uses an indeterminate bar. Publishing into Downloads shows actual copied-byte progress and marks the job saved only after MediaStore finalizes the file.
- Batch progress counts terminal jobs (saved, failed, or canceled); the text separately reports successful saves.
- The foreground-service notification mirrors the current transfer stage.
- The HTML preview is interactive but uses simulated media and transfers; it never contacts YouTube.
- Pure Kotlin model checks cover 54 cases (updated in v0.5). The Android UI and real downloads still require a build and device test.

## Appearance and brand (v0.3)
- Nazzelha / نزّلها replaces ClipShelf in the launcher, header, notifications and new save paths. Existing downloaded files are not moved; application ID is retained for upgrade compatibility.
- Settings > Appearance offers Follow system, Light, and Dark. Preference is stored on device; switching while reading metadata is blocked. Selection and an active foreground-service queue are held in memory and can be re-rendered after an appearance change.
- Dark: Ink #14191F, Coral #FF8075. Light: White #FFFFFF, Coral #B43B32. Both use semantic status colors and identical layouts and progress behavior. Palette contrast checks cover normal text on all three surfaces and button/progress contrast. Android device QA is still required, including changing themes while a service is downloading and while the system UI mode changes.

## v0.4: Live transfer metrics
- Download speed, stream ETA and stream size are read from yt-dlp progress output when available. ETA and speed are per current stream, not a playlist estimate or a network speed test. Unknown values stay unknown. FFmpeg and storage stages show their own status without stale network metrics.
- Notification shows live transfer metrics; HTML preview demonstrates simulated values only. Android build/device and live extraction are not verified in this environment.

## v0.5: Pre-download sizing and thumbnails
- Flat playlist metadata is rendered first; two background workers inspect available streams, prioritizing visible/newly selected items. Repeated video IDs in a playlist share their inspection results. A generation token ignores stale results after loading a new link. Format metadata is cached in memory for the current collection and a per-row plan cache avoids recalculating unchanged choices.
- Default video selection chooses the highest available resolution at or below the chosen cap, then a video-only stream at that height when available, plus the best-ranked audio-only stream according to yt-dlp's format ordering. If only a combined stream is usable at that resolution, its embedded audio is used without adding its size twice. Advanced explicit format selection remains possible. The exact selected format IDs are pinned for the download, so a disappeared format fails rather than silently downloading a different quality.
- Output size and source transfer size are distinct. Prefer `filesize`, then `filesize_approx`, then bitrate × duration / 8. Merged output size is an estimate (container overhead varies). MP3 target output size is estimated from the chosen target bitrate and duration; the source data transfer can be different. Some conversions, especially FLAC, have unknown final size. Unknown sizes are never represented as zero. Playlist totals include selected items only and indicate unknown entries. The app requires formats (but not necessarily a known size) for all selected items before starting. A failed inspection can be retried or the item deselected.
- Real YouTube thumbnails load asynchronously in playlist and download rows, with a medium-resolution fallback and duration overlay. Coil 2.7.0 provides memory/disk caching, size-aware decoding and request replacement when a row is reused. Thumbnail errors leave a placeholder. No thumbnails are downloaded as extra media files.
- The 54 pure Kotlin tests passed. The interactive HTML prototype was exercised in Chromium at mobile viewport: changing video resolution and MP3 bitrate updated displayed sizes, and thumbnails remained in the playlist and queue. The preview uses fictional videos/bitrate estimates and illustrative thumbnail SVGs, not live YouTube data.
- Android SDK/Gradle are unavailable here, so no APK was built or live network/device performance benchmark run. Validate extraction, concurrency, image loading, scrolling, pinned format availability, media playback, and file sizes on a real device before release. A rendered size is not a promise of exact final disk use.
- Upstream format sorting reference: https://github.com/yt-dlp/yt-dlp#sorting-formats ; image library: https://github.com/coil-kt/coil .
