package com.clipshelf.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.yausername.youtubedl_android.YoutubeDL
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

object QueueStore {
    @Volatile var states: List<JobState> = emptyList(); private set
    @Volatile var running = false; private set
    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    fun listen(callback: () -> Unit) { listeners.add(callback) }
    fun unlisten(callback: () -> Unit) { listeners.remove(callback) }
    private fun notifyChange() { main.post { listeners.forEach { it() } } }
    @Synchronized fun begin(jobs: List<Job>): Boolean {
        if (running || jobs.isEmpty()) return false
        states = jobs.map { JobState(it) }; running = true; notifyChange(); return true
    }
    @Synchronized fun change(key: String, transform: (JobState) -> JobState) {
        states = states.map { if (it.job.key == key) transform(it) else it }; notifyChange()
    }
    @Synchronized fun finish() { running = false; notifyChange() }
    @Synchronized fun abort(message: String) {
        states = states.map { if (it.phase == Phase.WAITING || it.phase.active) it.copy(phase = Phase.FAILED, message = message, metrics = null) else it }; running = false; notifyChange()
    }
}

class DownloadService : Service() {
    companion object { const val CANCEL = "com.clipshelf.app.CANCEL"; private const val CHANNEL = "clipshelf_download"; private const val ID = 42 }
    @Volatile private var canceled = false
    @Volatile private var activeId: String? = null
    private var started = false
    private val manager get() = getSystemService(NotificationManager::class.java)!!
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == CANCEL) { cancel(); if (!started) stopSelf(); return START_NOT_STICKY }
        if (started) return START_NOT_STICKY
        if (!QueueStore.running) { stopSelf(); return START_NOT_STICKY }
        started = true
        val notification = notification("Preparing downloads", 0, true)
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(ID, notification)
        thread(name = "clipshelf-download-worker") { runQueue() }
        return START_NOT_STICKY
    }
    private fun cancel() {
        canceled = true
        activeId?.let { id -> thread { runCatching { YoutubeDL.destroyProcessById(id) } } }
    }
    private fun runQueue() {
        val jobs = QueueStore.states.map { it.job }
        var succeeded = 0; var failed = 0; var lastNotify = 0L
        try {
            for ((position, job) in jobs.withIndex()) {
                if (canceled) { QueueStore.change(job.key) { it.copy(phase = Phase.CANCELED, message = "Canceled") }; continue }
                activeId = job.key
                QueueStore.change(job.key) { it.copy(phase = Phase.DOWNLOADING, message = "Connecting…") }
                manager.notify(ID, notification("${position + 1}/${jobs.size} · ${job.clip.title}", 0, true))
                var lastProgress = 0L
                var lastPhase: Phase? = null
                var lastIndeterminate: Boolean? = null
                try {
                    val uri = Engine.download(this, job, job.key, { canceled }) { update ->
                        val now = System.currentTimeMillis()
                        val indeterminate = update.percent == null
                        val changed = update.phase != lastPhase || indeterminate != lastIndeterminate
                        if (changed || now - lastProgress > 350) {
                            lastProgress = now; lastPhase = update.phase; lastIndeterminate = indeterminate
                            QueueStore.change(job.key) { it.copy(phase = update.phase, progress = update.percent, message = update.message, metrics = update.metrics) }
                            if (changed || now - lastNotify > 1000) {
                                lastNotify = now
                                manager.notify(ID, notification("${position + 1}/${jobs.size} · ${update.metrics?.summary()?.takeIf { it.isNotBlank() } ?: update.message}", update.percent ?: 0, indeterminate))
                            }
                        }
                    }
                    succeeded++
                    QueueStore.change(job.key) { it.copy(phase = Phase.DONE, progress = 100, message = "Saved", uri = uri.toString(), metrics = null) }
                } catch (e: Exception) {
                    if (!canceled) failed++
                    QueueStore.change(job.key) { it.copy(phase = if (canceled) Phase.CANCELED else Phase.FAILED, message = if (canceled) "Canceled" else (e.message ?: "Download failed").takeLast(1800), metrics = null) }
                } finally { activeId = null }
            }
        } finally {
            val summary = "$succeeded saved · $failed failed" + if (canceled) " · Canceled" else ""
            Handler(Looper.getMainLooper()).post {
                stopForeground(STOP_FOREGROUND_REMOVE)
                manager.notify(ID + 1, notification(summary, 100, false, false))
                QueueStore.finish()
                stopSelf()
            }
        }
    }
    private fun notification(text: String, progress: Int, indeterminate: Boolean, ongoing: Boolean = true): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val cancel = PendingIntent.getService(this, 1, Intent(this, DownloadService::class.java).setAction(CANCEL), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("Nazzelha").setContentText(text).setContentIntent(open).setOnlyAlertOnce(true).setOngoing(ongoing).apply {
            if (ongoing) { setProgress(100, progress, indeterminate); addAction(Notification.Action.Builder(null, "Cancel batch", cancel).build()) } else setAutoCancel(true)
        }.build()
    }
    override fun onTimeout(startId: Int, fgsType: Int) { cancel(); stopSelf() }
    override fun onDestroy() { if (QueueStore.running) cancel(); super.onDestroy() }
}
