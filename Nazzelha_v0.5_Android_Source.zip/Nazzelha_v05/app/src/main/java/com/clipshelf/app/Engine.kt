package com.clipshelf.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

object Engine {
    @Volatile private var initialized = false
    @Synchronized fun init(context: Context) {
        if (initialized) return
        YoutubeDL.init(context.applicationContext)
        FFmpeg.init(context.applicationContext)
        initialized = true
    }
    fun update(context: Context): String {
        init(context)
        val result = YoutubeDL.updateYoutubeDL(context.applicationContext, YoutubeDL.UpdateChannel.STABLE)
        return "${result ?: "Updated"} · ${YoutubeDL.version(context) ?: "yt-dlp"}"
    }
    private fun request(url: String) = YoutubeDLRequest(url).apply {
        addOption("--ignore-config"); addOption("--no-colors")
        addOption("--socket-timeout", 25); addOption("--retries", 3)
        addOption("--remote-components", "ejs:github")
    }
    private fun json(request: YoutubeDLRequest, processId: String = UUID.randomUUID().toString()): JSONObject {
        request.addOption("--dump-single-json"); request.addOption("--skip-download")
        val r = YoutubeDL.execute(request, processId, false, null)
        if (r.exitCode != 0) error(r.err.ifBlank { "Metadata command failed" })
        return JSONObject(r.out.trim())
    }
    fun fetch(context: Context, url: String, playlist: Boolean): Collection {
        init(context)
        val req = request(url)
        if (playlist) { req.addOption("--yes-playlist"); req.addOption("--flat-playlist"); req.addOption("--ignore-errors") }
        else req.addOption("--no-playlist")
        val root = json(req)
        val entries = root.optJSONArray("entries")
        if (entries == null) return Collection(root.string("title", "Video"), false, listOf(parseClip(root, 1, url)))
        val items = (0 until entries.length()).mapNotNull { pos ->
            val item = entries.optJSONObject(pos) ?: return@mapNotNull null
            parseClip(item, pos + 1, "")
        }
        require(items.isNotEmpty()) { "No videos were found in this playlist." }
        return Collection(root.string("title", "Playlist"), true, items)
    }
    fun inspect(context: Context, clip: Clip, processId: String = UUID.randomUUID().toString()): Clip {
        if (clip.streams.isNotEmpty()) return clip
        init(context)
        val req = request(clip.url).addOption("--no-playlist")
        val info = parseClip(json(req, processId), clip.index, clip.url)
        require(info.available && info.streams.isNotEmpty()) { "No downloadable audio or video streams were returned." }
        return info.copy(index = clip.index, url = clip.url, duration = info.duration.takeIf { it > 0 } ?: clip.duration, thumbnail = clip.thumbnail.ifBlank { info.thumbnail })
    }
    private fun parseClip(o: JSONObject, index: Int, originalUrl: String): Clip {
        val id = o.string("id", "")
        val title = o.string("title", "Video $index")
        val url = Rules.youtubeLink(o.string("webpage_url", "")) ?: Rules.youtubeLink(o.string("url", "")) ?: Rules.youtubeLink(originalUrl)
            ?: if (id.matches(Regex("[A-Za-z0-9_-]{11}"))) "https://www.youtube.com/watch?v=$id" else ""
        val status = o.string("availability", "")
        val isAvailable = url.isNotBlank() && status !in setOf("private", "premium_only", "subscriber_only", "needs_auth") &&
            title !in setOf("[Private video]", "[Deleted video]", "Private video", "Deleted video") && o.string("live_status", "") !in setOf("is_live", "is_upcoming")
        val thumbs = o.optJSONArray("thumbnails")
        val candidates = (0 until (thumbs?.length() ?: 0)).mapNotNull { i -> thumbs?.optJSONObject(i)?.let { it.string("url", "") to it.optInt("width") } }
        val thumb = ThumbnailRules.pick(id, candidates, o.string("thumbnail", ""))
        val formats = o.optJSONArray("formats") ?: JSONArray()
        val streams = (0 until formats.length()).mapNotNull { i ->
            val f = formats.optJSONObject(i) ?: return@mapNotNull null
            val fmtId = f.string("format_id", "")
            if (!fmtId.matches(Regex("[A-Za-z0-9_.-]+")) || f.optBoolean("has_drm", false) || f.string("protocol", "") == "mhtml") return@mapNotNull null
            val size = f.optLong("filesize", 0L).coerceAtLeast(0L)
            val approx = f.optLong("filesize_approx", 0L).coerceAtLeast(0L)
            val abr = f.optDouble("abr", 0.0).takeIf { it.isFinite() && it > 0 } ?: 0.0
            val tbr = f.optDouble("tbr", 0.0).takeIf { it.isFinite() && it > 0 } ?: 0.0
            val vbr = f.optDouble("vbr", 0.0).takeIf { it.isFinite() && it > 0 } ?: 0.0
            val isVideo = f.string("vcodec", "") !in setOf("", "none", "unknown")
            Stream(fmtId, f.string("ext", ""), f.optInt("width"), f.optInt("height"), f.optDouble("fps", 0.0).toInt(), f.string("vcodec", ""), f.string("acodec", ""), if (isVideo) tbr.takeIf { it > 0 } ?: vbr else abr.takeIf { it > 0 } ?: tbr, if (size > 0) size else approx, f.string("format_note", ""), size == 0L && approx > 0, abr, tbr).takeIf { it.video || it.audio }
        }.distinctBy { it.id }
        return Clip(o.optInt("playlist_index", index).takeIf { it > 0 } ?: index, id, title, url, o.optLong("duration"), thumb, isAvailable, streams)
    }
    private fun JSONObject.string(key: String, fallback: String): String = if (isNull(key)) fallback else optString(key, fallback).ifBlank { fallback }

    fun download(context: Context, job: Job, processId: String, canceled: () -> Boolean, progress: (TransferUpdate) -> Unit): Uri {
        init(context)
        val dir = File(context.cacheDir, "clipshelf/${job.key}")
        check(dir.mkdirs() || dir.isDirectory) { "Cannot create temporary folder" }
        try {
            if (canceled()) throw InterruptedException("Canceled")
            val req = request(job.clip.url).apply {
                addOption("--no-playlist"); addOption("--newline"); addOption("--progress")
                addOption("--no-mtime"); addOption("--no-overwrites"); addOption("--no-write-subs")
                addOption("--no-write-thumbnail"); addOption("--no-write-info-json")
                addOption("--cache-dir", File(context.cacheDir, "yt-cache").absolutePath)
                addOption("-o", File(dir, "media.%(ext)s").absolutePath)
                Rules.formatOptions(job.choice).forEach { (k, v) -> if (v == null) addOption(k) else addOption(k, v) }
            }
            val result = YoutubeDL.execute(req, processId, false) { p, eta, line ->
                if (canceled()) YoutubeDL.destroyProcessById(processId)
                TransferProgress.fromCallback(p, eta.toLong(), line)?.let(progress)
            }
            if (canceled()) throw InterruptedException("Canceled")
            check(result.exitCode == 0) { result.err.ifBlank { "Download failed" } }
            val file = dir.listFiles()?.filter { it.isFile && it.name.matches(Regex("media\\.[A-Za-z0-9]+")) && it.length() > 0 }?.maxByOrNull { it.length() }
                ?: error("No finished media file found")
            progress(TransferProgress.saving(0, file.length()))
            return publish(context, file, job, canceled, progress)
        } finally { dir.deleteRecursively() }
    }
    private fun publish(context: Context, file: File, job: Job, canceled: () -> Boolean, progress: (TransferUpdate) -> Unit): Uri {
        val resolver = context.contentResolver
        val name = Rules.fileName(job, file.extension)
        val mime = when (file.extension.lowercase()) { "mp4", "m4v" -> "video/mp4"; "webm" -> if (job.choice.mode == Mode.AUDIO) "audio/webm" else "video/webm"; "mkv" -> "video/x-matroska"; "m4a" -> "audio/mp4"; "mp3" -> "audio/mpeg"; "opus", "ogg" -> "audio/ogg"; "flac" -> "audio/flac"; "wav" -> "audio/wav"; else -> "application/octet-stream" }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, job.folder); put(MediaStore.MediaColumns.IS_PENDING, 1)
        }) ?: error("Could not create file in Downloads")
        try {
            file.inputStream().use { input ->
                (resolver.openOutputStream(uri, "w") ?: error("Cannot open output file")).use { out ->
                    val buffer = ByteArray(256 * 1024)
                    var copied = 0L
                    val total = file.length()
                    while (true) {
                        if (canceled()) throw InterruptedException("Canceled")
                        val n = input.read(buffer); if (n < 0) break; out.write(buffer, 0, n)
                        copied += n
                        progress(TransferProgress.saving(copied, total))
                    }
                }
            }
            if (canceled()) throw InterruptedException("Canceled")
            check(resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null) > 0) { "Cannot finalize output" }
            return uri
        } catch (e: Exception) { resolver.delete(uri, null, null); throw e }
    }
}
