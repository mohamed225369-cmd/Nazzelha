package com.clipshelf.app

internal data class Palette(
    val background: Int,
    val panel: Int,
    val panel2: Int,
    val accent: Int,
    val onAccent: Int,
    val ink: Int,
    val soft: Int,
    val red: Int,
    val line: Int,
    val green: Int
)

internal object NazzelhaColors {
    val dark = Palette(
        background = 0xFF14191F.toInt(),
        panel = 0xFF1C232B.toInt(),
        panel2 = 0xFF242C35.toInt(),
        accent = 0xFFFF8075.toInt(),
        onAccent = 0xFF231818.toInt(),
        ink = 0xFFF4F5F6.toInt(),
        soft = 0xFFA5AFBA.toInt(),
        red = 0xFFFFB4AB.toInt(),
        line = 0xFF39434E.toInt(),
        green = 0xFF8FD3AF.toInt()
    )
    val light = Palette(
        background = 0xFFFFFFFF.toInt(),
        panel = 0xFFF7F8FA.toInt(),
        panel2 = 0xFFEEF0F3.toInt(),
        accent = 0xFFB43B32.toInt(),
        onAccent = 0xFFFFFFFF.toInt(),
        ink = 0xFF20252B.toInt(),
        soft = 0xFF59636F.toInt(),
        red = 0xFFAA2626.toInt(),
        line = 0xFFD8DDE3.toInt(),
        green = 0xFF19714D.toInt()
    )
}
