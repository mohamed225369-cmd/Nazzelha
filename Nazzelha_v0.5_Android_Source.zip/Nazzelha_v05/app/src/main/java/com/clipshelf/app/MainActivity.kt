package com.clipshelf.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.view.WindowInsetsController
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.Looper
import android.graphics.drawable.ColorDrawable
import coil.load
import coil.dispose
import java.util.UUID
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.util.concurrent.Executors

private object Workspace {
    var link = ""
    var playlist = true
    var collection: Collection? = null
    val selection = linkedSetOf<Int>()
    val choices = mutableMapOf<Int, Choice>()
    val details = mutableMapOf<String, Clip>()
    val failures = mutableMapOf<String, String>()
    val plans = PlanCache()
    fun key(clip: Clip) = clip.id.ifBlank { clip.url }
    fun resolved(clip: Clip): Clip = details[key(clip)]?.let { if (it.index == clip.index) it else it.copy(index = clip.index) } ?: clip
    fun choice(clip: Clip) = choices[clip.index] ?: defaultChoice
    fun plan(clip: Clip) = plans.get(resolved(clip), choice(clip))
    var defaultChoice = Choice()
    var tab = 0
    var editingLink = true
}

class MainActivity : Activity() {
    // Theme preference persists; the palette also styles loading and download progress.
    private val prefs by lazy { getSharedPreferences("appearance", MODE_PRIVATE) }
    private val appearance get() = prefs.getString("theme", "system") ?: "system"
    private fun isDark(config: Configuration = resources.configuration) = when (appearance) {
        "dark" -> true
        "light" -> false
        else -> (config.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }
    private var darkMode = true
    private lateinit var palette: Palette
    private val background get() = palette.background
    private val panel get() = palette.panel
    private val panel2 get() = palette.panel2
    private val accent get() = palette.accent
    private val onAccent get() = palette.onAccent
    private val ink get() = palette.ink
    private val soft get() = palette.soft
    private val red get() = palette.red
    private val line get() = palette.line
    private val green get() = palette.green
    private val ripple get() = if (darkMode) 0x22FFFFFF else 0x22000000
    private val main = Handler(Looper.getMainLooper())
    private val metadataWorkers = Executors.newFixedThreadPool(2)
    private var scanCollection: Collection? = null
    private var generation = 0L
    private val pending = linkedMapOf<String, Clip>()
    private val urgent = linkedSetOf<String>()
    private val activeMetadata = linkedMapOf<String, Pair<Long, String>>()
    private var redrawPending = false
    private var qualitySheetRefresh: (() -> Unit)? = null
    private var sizeLabel: TextView? = null
    private var metadataLabel: TextView? = null
    private var metadataTrack: ProgressBar? = null
    private var retryMetadata: Button? = null
    private var defaultLabel: TextView? = null
    private val worker = Executors.newSingleThreadExecutor()
    private var busy = false
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var tabs: LinearLayout
    private lateinit var footer: LinearLayout
    private var queueAdapter: QueueAdapter? = null
    private var queueHeader: TextView? = null
    private var queueProgress: ProgressBar? = null
    private var loadingProgress: ProgressBar? = null
    private var busyDescription = ""
    private var queueFooterState: Boolean? = null
    private var tabSignature = ""
    private var listAdapter: ClipAdapter? = null
    private var summaryLabel: TextView? = null
    private var downloadButton: Button? = null
    private var fetchButton: Button? = null
    private var status: TextView? = null
    private var linkInput: EditText? = null
    private var lastQueueRunning = false
    private val queueListener: () -> Unit = {
        val changed = lastQueueRunning != QueueStore.running
        lastQueueRunning = QueueStore.running
        refreshTabs()
        if (Workspace.tab == 1) renderQueue() else refreshSelection(changed)
        if (!QueueStore.running) kickMetadata()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        darkMode = isDark()
        palette = if (darkMode) NazzelhaColors.dark else NazzelhaColors.light
        setTheme(if (darkMode) R.style.AppTheme else R.style.AppTheme_Light)
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 30) {
            val flags = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (darkMode) 0 else flags, flags)
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = if (darkMode) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.statusBarColor = background; window.navigationBarColor = background
        root = column(0).apply { setBackgroundColor(background); setPadding(dp(20), dp(8), dp(20), dp(6)) }
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            root.setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                view.setPadding(dp(20) + bars.left, dp(8) + bars.top, dp(20) + bars.right, dp(6) + maxOf(bars.bottom, ime.bottom))
                insets
            }
        }
        val header = row()
        header.addView(ImageView(this).apply { setImageResource(com.clipshelf.app.R.drawable.ic_logo); contentDescription = null }, lp(36, 36))
        header.addView(space(10))
        header.addView(label("نزّلها", 23, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button("Settings") { showSettings() })
        root.addView(header, lp(-1, 52))
        body = column(0); root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        footer = column(0); root.addView(footer)
        root.addView(rule(), lp(-1, 1, 8))
        tabs = row(); root.addView(tabs, lp(-1, 56, 4))
        setContentView(root)
        if (savedInstanceState == null) handleShare(intent)
        QueueStore.listen(queueListener)
        showTab(Workspace.tab)
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); if (intent.action == Intent.ACTION_SEND) linkInput = null; handleShare(intent); showTab(Workspace.tab) }
    override fun onDestroy() { QueueStore.unlisten(queueListener); generation++; pending.clear(); urgent.clear(); main.removeCallbacksAndMessages(null); worker.shutdownNow(); metadataWorkers.shutdownNow(); super.onDestroy() }
    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { Rules.youtubeLink(it) }?.let { Workspace.link = it; Workspace.tab = 0; Workspace.editingLink = true }
        }
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun lp(w: Int, h: Int, top: Int = 0) = LinearLayout.LayoutParams(if (w < 0) w else dp(w), if (h < 0) h else dp(h)).apply { topMargin = dp(top) }
    private fun shape(color: Int, radius: Int = 10, stroke: Int? = null) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); if (stroke != null) setStroke(dp(1), stroke) }
    private fun column(padding: Int = 0) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; if (padding > 0) setPadding(dp(padding), dp(padding), dp(padding), dp(padding)) }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun label(text: String, size: Int = 14, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL); setLineSpacing(dp(2).toFloat(), 1f); includeFontPadding = false
    }
    private fun progressTrack(value: Int?, description: String) = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 100; isIndeterminate = value == null; progress = value ?: 0
        progressTintList = ColorStateList.valueOf(accent)
        progressBackgroundTintList = ColorStateList.valueOf(panel2)
        indeterminateTintList = ColorStateList.valueOf(accent)
        contentDescription = description
    }
    private fun rule() = View(this).apply { setBackgroundColor(line); importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO }
    private fun button(text: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(ColorStateList(arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()), intArrayOf(soft, if (primary) onAccent else ink)))
        val states = StateListDrawable().apply {
            addState(intArrayOf(-android.R.attr.state_enabled), shape(panel2, 10))
            addState(intArrayOf(), shape(if (primary) accent else panel2, 10))
        }
        background = RippleDrawable(ColorStateList.valueOf(if (primary) 0x22000000 else ripple), states, null)
        stateListAnimator = null; elevation = 0f
        minHeight = dp(48); minimumHeight = dp(48); minWidth = 0; minimumWidth = 0
        setPadding(dp(12), dp(4), dp(12), dp(4)); setOnClickListener { action() }
    }
    private fun quiet(text: String, active: Boolean = false, action: () -> Unit) = button(text, false, action).apply {
        background = RippleDrawable(ColorStateList.valueOf(ripple), shape(if (active) panel2 else Color.TRANSPARENT), shape(Color.WHITE))
        setTextColor(ColorStateList(arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()), intArrayOf(soft, if (active) accent else soft)))
        isSelected = active
    }
    private fun checkbox(text: String? = null) = CheckBox(this).apply {
        text?.let { this.text = it }; setTextColor(ink); buttonTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(accent, soft)); minHeight = dp(48); minWidth = dp(48)
    }
    private fun compactChoice(choice: Choice): String = if (choice.mode == Mode.VIDEO) {
        choice.videoId?.let { "Video #$it" } ?: choice.maxHeight?.let { "Up to ${it}p" } ?: "Best video"
    } else if (choice.audioType == AudioType.MP3) "MP3 · ${choice.mp3Quality.removeSuffix("K")} kbps" else if (choice.audioType == AudioType.ORIGINAL) "Original audio" else choice.audioType.label
    private fun showSettings() {
        val current = when (appearance) { "light" -> "Light"; "dark" -> "Dark"; else -> "System" }
        AlertDialog.Builder(this).setTitle("Settings").setItems(arrayOf("Appearance · $current", "Update yt-dlp", "About Nazzelha")) { _, which ->
            when (which) {
                0 -> chooseAppearance()
                1 -> updateEngine()
                else -> AlertDialog.Builder(this).setTitle("About نزّلها").setMessage("Media downloads stay on your device. Save only content you have permission to download.\n\nPowered by yt-dlp and FFmpeg.").setPositiveButton("Done", null).show()
            }
        }.show()
    }
    private fun chooseAppearance() {
        if (busy) return message("Finish reading the link or formats before changing appearance.")
        val options = arrayOf("system", "light", "dark")
        AlertDialog.Builder(this).setTitle("Appearance")
            .setSingleChoiceItems(arrayOf("Follow system", "Light", "Dark"), options.indexOf(appearance).coerceAtLeast(0)) { dialog, which ->
                dialog.dismiss()
                if (options[which] != appearance) {
                    linkInput?.let { Workspace.link = it.text.toString() }
                    prefs.edit().putString("theme", options[which]).apply()
                    recreate()
                }
            }.setNegativeButton("Cancel", null).show()
    }
    private fun space(width: Int) = Space(this).apply { layoutParams = lp(width, 1) }
    private fun weightButton(row: LinearLayout, b: Button) = row.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
    private fun refreshTabs() {
        val done = QueueStore.states.count { it.phase == Phase.DONE }
        val signature = "${Workspace.tab}:$done:${QueueStore.states.size}"
        if (signature == tabSignature) return
        tabSignature = signature
        tabs.removeAllViews()
        weightButton(tabs, quiet("Add media", Workspace.tab == 0) { showTab(0) }); tabs.addView(space(8))
        val suffix = if (QueueStore.states.isNotEmpty()) "  $done/${QueueStore.states.size}" else ""
        weightButton(tabs, quiet("Downloads$suffix", Workspace.tab == 1) { showTab(1) })
    }
    private fun showTab(tab: Int) {
        linkInput?.let { Workspace.link = it.text.toString() }
        Workspace.tab = tab; body.removeAllViews(); footer.removeAllViews()
        linkInput = null; status = null; fetchButton = null; summaryLabel = null; sizeLabel = null; metadataLabel = null; metadataTrack = null; retryMetadata = null; defaultLabel = null; downloadButton = null; listAdapter = null; queueAdapter = null; queueHeader = null; queueProgress = null; loadingProgress = null; queueFooterState = null
        refreshTabs()
        if (tab == 0) renderLibrary() else buildQueue()
    }
    private fun renderLibrary() {
        val collection = Workspace.collection
        if (collection == null || Workspace.editingLink) {
            val content = column(0)
            val scroll = ScrollView(this).apply { isFillViewport = false; isVerticalScrollBarEnabled = false; addView(content) }
            body.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
            content.addView(label("Add media", 28, ink, true), lp(-1, -2, 18))
            content.addView(label("Paste a video or playlist link to choose what to save.", 14, soft), lp(-1, -2, 8))
            val linkRow = row().apply { background = shape(panel, 10, line); setPadding(dp(12), 0, dp(4), 0) }
            val edit = EditText(this).apply {
                hint = "YouTube link"; setText(Workspace.link); setTextColor(ink); setHintTextColor(soft)
                textSize = 15f; maxLines = 1; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
                setPadding(0, dp(12), 0, dp(12)); background = null; minHeight = dp(52)
                contentDescription = "YouTube video or playlist URL"
            }
            linkInput = edit; linkRow.addView(edit, LinearLayout.LayoutParams(0, -2, 1f)); linkRow.addView(space(8))
            linkRow.addView(quiet("Paste", true) {
                val clipboard = getSystemService(ClipboardManager::class.java)!!
                edit.setText(clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: "")
            }); content.addView(linkRow, lp(-1, 56, 20))
            val playlist = checkbox("Include playlist").apply { isChecked = Workspace.playlist; setOnCheckedChangeListener { _, checked -> Workspace.playlist = checked } }
            content.addView(playlist, lp(-1, -2, 6))
            fetchButton = button(if (busy) "Reading link…" else "Load link", true) { fetch() }.apply { isEnabled = !busy && !QueueStore.running }
            content.addView(fetchButton!!, lp(-1, 52, 6))
            loadingProgress = progressTrack(null, "Loading link").apply { visibility = if (busy) View.VISIBLE else View.GONE }
            content.addView(loadingProgress!!, lp(-1, 6, 12))
            status = label(if (busy) busyDescription else "", 12, soft); content.addView(status!!, lp(-1, -2, 8))
            if (collection != null) {
                content.addView(quiet("Back to current selection") { Workspace.editingLink = false; showTab(0) }, lp(-1, 48, 10))
            } else {
                content.addView(rule(), lp(-1, 1, 20))
                content.addView(label("How it works", 16, ink, true), lp(-1, -2, 20))
                listOf("01" to "Load a video or playlist", "02" to "Select videos and set quality", "03" to "Save to your Downloads folder").forEach { (n, text) ->
                    val r = row(); r.addView(label(n, 13, soft, true), lp(36, -2)); r.addView(label(text, 14, ink), LinearLayout.LayoutParams(0, -2, 1f)); content.addView(r, lp(-1, 44))
                }
            }
            footer.addView(label("Files are saved on your device. Only download content you have permission to save.", 12, soft))
            return
        }
        val top = row()
        top.addView(label(if (collection.playlist) "PLAYLIST" else "VIDEO", 11, soft, true).apply { letterSpacing = .10f }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(quiet("Change link") { Workspace.editingLink = true; showTab(0) })
        body.addView(top, lp(-1, 48, 4))
        body.addView(label(collection.title, 26, ink, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }, lp(-1, -2, 2))
        val total = collection.items.sumOf { it.duration }
        body.addView(label("${collection.items.size} ${if (collection.items.size == 1) "video" else "videos"} · ${Rules.duration(total)}", 13, soft), lp(-1, -2, 6))
        val settings = row().apply { background = shape(panel, 10, line); setPadding(dp(12), 0, dp(6), 0) }
        val settingsText = column(0)
        settingsText.addView(label("Default quality", 12, soft))
        defaultLabel = label(compactChoice(Workspace.defaultChoice), 15, ink, true)
        settingsText.addView(defaultLabel!!, lp(-1, -2, 3))
        settings.addView(settingsText, LinearLayout.LayoutParams(0, -2, 1f))
        settings.addView(quiet("Edit", true) { editChoice(null, false) })
        body.addView(settings, lp(-1, 64, 14))
        val actions = row()
        summaryLabel = label("", 13, ink, true); actions.addView(summaryLabel!!, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(quiet("All") { Workspace.selection.clear(); Workspace.selection.addAll(collection.items.filter { it.available }.map { it.index }); refreshSelection() })
        actions.addView(quiet("None") { Workspace.selection.clear(); refreshSelection() })
        body.addView(actions, lp(-1, 48, 6))
        val metaRow = row()
        metadataLabel = label("", 12, soft); metaRow.addView(metadataLabel!!, LinearLayout.LayoutParams(0, -2, 1f))
        retryMetadata = quiet("Retry", true) { retryFailed() }.apply { visibility = View.GONE }
        metaRow.addView(retryMetadata!!, lp(-2, 48)); body.addView(metaRow)
        metadataTrack = progressTrack(0, "Reading available qualities")
        body.addView(metadataTrack!!, lp(-1, 5, 6))
        body.addView(rule(), lp(-1, 1))
        listAdapter = ClipAdapter(collection.items)
        val list = ListView(this).apply { adapter = listAdapter; divider = null; dividerHeight = 0; isVerticalScrollBarEnabled = false; clipToPadding = false }
        body.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView?, state: Int) {}
            override fun onScroll(view: AbsListView?, first: Int, visible: Int, total: Int) {
                val items = Workspace.collection?.items ?: return
                for (i in first until minOf(items.size, first + visible)) prioritize(items[i])
                kickMetadata()
            }
        })
        footer.addView(rule(), lp(-1, 1))
        sizeLabel = label("", 13, ink, true); footer.addView(sizeLabel!!, lp(-1, -2, 9))
        footer.addView(label("Save to", 12, soft), lp(-1, -2, 6))
        footer.addView(label(Rules.folder(collection.title, collection.playlist), 13, ink).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }, lp(-1, -2, 4))
        downloadButton = button("Download selected", true) { startDownloads() }; footer.addView(downloadButton!!, lp(-1, 52, 12))
        prepareMetadata(collection)
        refreshSelection()
    }
    private fun refreshSelection(redraw: Boolean = true) {
        val collection = Workspace.collection ?: return
        if (Workspace.tab == 0 && summaryLabel != null) {
            val selected = collection.items.filter { it.available && it.index in Workspace.selection }
            val plans = selected.map { Workspace.plan(it) }
            val pendingCount = selected.count { Workspace.resolved(it).streams.isEmpty() && Workspace.key(it) !in Workspace.failures }
            val invalid = plans.count { it == null } - pendingCount
            val output = MediaSizes.total(plans.map { it?.output ?: SizeEstimate() })
            val transfer = MediaSizes.total(plans.map { it?.transfer ?: SizeEstimate() })
            summaryLabel?.text = "${selected.size} of ${collection.items.size} selected"
            sizeLabel?.text = "Save: ${output.label()}\nData: ${transfer.label()}"
            val available = collection.items.filter { it.available }
            val ready = available.count { Workspace.resolved(it).streams.isNotEmpty() }
            val failures = available.count { Workspace.key(it) in Workspace.failures }
            metadataLabel?.text = when {
                ready == available.size -> "Qualities ready · sizes may be estimated"
                ready + failures == available.size -> "$ready ready · $failures unavailable"
                else -> "Reading qualities · $ready/${available.size}" + if (failures > 0) " · $failures failed" else ""
            }
            metadataTrack?.apply { max = available.size.coerceAtLeast(1); progress = ready + failures; visibility = if (ready + failures < available.size) View.VISIBLE else View.GONE }
            retryMetadata?.visibility = if (failures > 0) View.VISIBLE else View.GONE
            defaultLabel?.text = compactChoice(Workspace.defaultChoice)
            downloadButton?.apply {
                text = when {
                    QueueStore.running -> "Download in progress"
                    pendingCount > 0 -> "Reading $pendingCount selected…"
                    invalid > 0 -> "Review $invalid selection(s)"
                    else -> "Download ${selected.size} ${if (selected.size == 1) "item" else "items"}"
                }
                isEnabled = selected.isNotEmpty() && pendingCount == 0 && invalid == 0 && !busy && !QueueStore.running
            }
        }
        fetchButton?.isEnabled = !busy && !QueueStore.running
        if (redraw) listAdapter?.notifyDataSetChanged()
    }
    private fun prepareMetadata(collection: Collection) {
        if (scanCollection === collection) { kickMetadata(); return }
        generation++; scanCollection = collection; pending.clear(); urgent.clear()
        for (clip in collection.items) if (clip.available && Workspace.resolved(clip).streams.isEmpty() && Workspace.key(clip) !in Workspace.failures)
            pending.putIfAbsent(Workspace.key(clip), clip)
        kickMetadata()
    }
    private fun prioritize(clip: Clip) { val key = Workspace.key(clip); if (key in pending) urgent.add(key) }
    private fun kickMetadata() {
        if (isDestroyed || isFinishing || busy || QueueStore.running || scanCollection !== Workspace.collection) return
        while (activeMetadata.size < 2 && pending.isNotEmpty()) {
            val key = urgent.firstOrNull { it in pending && it !in activeMetadata }
                ?: pending.keys.firstOrNull { it !in activeMetadata } ?: break
            urgent.remove(key)
            val clip = pending.remove(key) ?: continue
            val token = generation; val id = UUID.randomUUID().toString()
            activeMetadata[key] = token to id
            metadataWorkers.execute {
                val result = runCatching { Engine.inspect(applicationContext, clip, id) }
                main.post {
                    activeMetadata.remove(key)
                    if (isDestroyed || isFinishing) return@post
                    if (token == generation && scanCollection === Workspace.collection) {
                        result.onSuccess { Workspace.details[key] = it; Workspace.failures.remove(key) }
                            .onFailure { Workspace.failures[key] = it.message ?: "Could not read formats" }
                        scheduleMetadataRedraw()
                    }
                    kickMetadata()
                }
            }
        }
    }
    private fun scheduleMetadataRedraw() {
        if (redrawPending) return
        redrawPending = true
        main.postDelayed({ redrawPending = false; if (!isDestroyed) { refreshSelection(); qualitySheetRefresh?.invoke() } }, 150)
    }
    private fun retryFailed() {
        val collection = Workspace.collection ?: return
        for (clip in collection.items) if (Workspace.failures.remove(Workspace.key(clip)) != null) pending[Workspace.key(clip)] = clip
        refreshSelection(); kickMetadata()
    }
    private inner class ThumbView : FrameLayout(this@MainActivity) {
        private val placeholderText = label("", 14, soft, true).apply { gravity = Gravity.CENTER }
        private val image = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = null }
        private val duration = label("", 10, Color.WHITE, true).apply { setPadding(dp(4), dp(2), dp(4), dp(2)); background = shape(0xCC14191F.toInt(), 3) }
        private var lastUrl: String? = null
        init {
            background = shape(panel2, 6); clipToOutline = true
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
            addView(placeholderText, FrameLayout.LayoutParams(-1, -1)); addView(image, FrameLayout.LayoutParams(-1, -1))
            addView(duration, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT).apply { rightMargin = dp(3); bottomMargin = dp(3) })
        }
        fun bind(clip: Clip) {
            placeholderText.text = clip.index.toString().padStart(2, '0')
            duration.text = Rules.duration(clip.duration); duration.visibility = if (clip.duration > 0) View.VISIBLE else View.GONE
            val url = clip.thumbnail.takeIf(ThumbnailRules::valid) ?: ThumbnailRules.fallback(clip.id)
            if (lastUrl == url) return
            lastUrl = url; image.dispose(); image.setImageDrawable(null)
            if (url.isNotBlank()) image.load(url) {
                size(dp(104), dp(60)); crossfade(false)
                placeholder(ColorDrawable(Color.TRANSPARENT)); error(ColorDrawable(Color.TRANSPARENT))
            }
        }
    }
    private inner class ClipRow : LinearLayout(this@MainActivity) {
        private val check = checkbox()
        private val thumb = ThumbView()
        private val title = label("", 14, ink, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        private val details = label("", 12, soft).apply { maxLines = 2 }
        private val size = label("", 12, ink, true).apply { maxLines = 2 }
        private var bound: Clip? = null
        private val edit = quiet("Edit") { bound?.let { editChoice(Workspace.resolved(it), false) } }
        init {
            orientation = VERTICAL
            val r = row().apply { setPadding(0, dp(10), 0, dp(10)); minimumHeight = dp(88) }
            r.addView(check, lp(48, 48)); r.addView(thumb, lp(88, 50)); r.addView(space(10))
            val text = column(0); text.addView(title); text.addView(details, lp(-1, -2, 4)); text.addView(size, lp(-1, -2, 4))
            r.addView(text, LinearLayout.LayoutParams(0, -2, 1f)); r.addView(edit, lp(48, 48)); addView(r); addView(rule(), lp(-1, 1))
        }
        fun bind(base: Clip) {
            val clip = Workspace.resolved(base); bound = base
            check.setOnCheckedChangeListener(null); check.isEnabled = clip.available; check.isChecked = clip.index in Workspace.selection
            check.contentDescription = "Select ${clip.title}"
            check.setOnCheckedChangeListener { _, checked ->
                if (checked) { Workspace.selection.add(clip.index); prioritize(base); kickMetadata() } else Workspace.selection.remove(clip.index)
                refreshSelection(false)
            }
            thumb.bind(clip); title.text = clip.title
            val choice = Workspace.choice(clip); val plan = Workspace.plan(base); val failed = Workspace.key(clip) in Workspace.failures
            val custom = clip.index in Workspace.choices
            details.text = "${clip.index.toString().padStart(2, '0')} · " + when {
                !clip.available -> "Unavailable"
                plan != null -> plan.qualityLabel()
                else -> compactChoice(choice)
            } + if (custom) " · Custom" else ""
            details.setTextColor(if (!clip.available || failed) red else if (custom) accent else soft)
            size.text = when {
                !clip.available -> "Unavailable"
                failed -> "Formats failed · retry"
                clip.streams.isEmpty() -> "Reading size…"
                plan == null -> "Quality unavailable · edit"
                else -> plan.output.label() + if (plan.output != plan.transfer) " · Data ${plan.transfer.label()}" else ""
            }
            size.setTextColor(if (failed || (clip.streams.isNotEmpty() && plan == null)) red else ink)
            edit.isEnabled = clip.available && !busy && !QueueStore.running; edit.contentDescription = "Edit quality for ${clip.title}"
        }
    }
    private inner class ClipAdapter(private val items: List<Clip>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = items[position].index.toLong()
        override fun hasStableIds() = true
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = (convertView as? ClipRow ?: ClipRow()).apply { bind(getItem(position)) }
    }
    private fun fetch() {
        if (busy || QueueStore.running) return
        val url = Rules.youtubeLink(linkInput?.text.toString()) ?: return message("Paste a valid YouTube video or playlist link.")
        Workspace.link = url
        linkInput?.setText(url)
        getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(linkInput?.windowToken, 0)
        val playlist = Workspace.playlist
        task("Reading link…", { Engine.fetch(applicationContext, url, playlist) }) { result ->
            Workspace.collection = result; Workspace.details.clear(); Workspace.failures.clear(); Workspace.plans.clear(); Workspace.editingLink = false; Workspace.selection.clear(); Workspace.choices.clear(); Workspace.selection.addAll(result.items.filter { it.available }.map { it.index }); showTab(0)
            status?.text = "${result.items.count { it.available }} available · choose Quality for exact formats"
        }
    }
    private fun updateEngine() {
        if (busy || QueueStore.running) return message("Finish the current operation before updating.")
        if (activeMetadata.isNotEmpty()) return message("Wait for quality information to finish loading before updating yt-dlp.")
        task("Updating yt-dlp…", { Engine.update(applicationContext) }) { message(it) }
    }
    private fun <T> task(description: String, action: () -> T, success: (T) -> Unit) {
        if (busy) return
        busy = true; busyDescription = description; status?.text = description; fetchButton?.text = "Working…"; refreshSelection()
        loadingProgress?.visibility = View.VISIBLE
        val dialog = if (loadingProgress == null) {
            val content = column(22)
            content.addView(label(description, 15, ink, true))
            content.addView(progressTrack(null, description), lp(-1, 6, 16))
            AlertDialog.Builder(this).setView(content).setCancelable(false).create().apply { show() }
        } else null
        worker.execute {
            val result = runCatching(action)
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                dialog?.dismiss(); busy = false; busyDescription = ""; loadingProgress?.visibility = View.GONE; fetchButton?.text = "Load link"; status?.text = ""; refreshSelection()
                result.onSuccess(success).onFailure { errorDialog(it.message ?: it.toString()) }; kickMetadata()
            }
        }
    }
    private fun spinner(options: List<String>, initial: Int = 0) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, options).apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        setSelection(initial.coerceIn(0, options.lastIndex)); backgroundTintList = ColorStateList.valueOf(accent); minimumHeight = dp(48)
    }
    private fun Spinner.onSelect(action: () -> Unit) { onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener { override fun onItemSelected(p: AdapterView<*>?, view: View?, position: Int, id: Long) { action() }; override fun onNothingSelected(p: AdapterView<*>?) {} } }
    private fun editChoice(clip: Clip?, exact: Boolean) {
        if (busy || QueueStore.running) return message("Wait for the current operation to finish.")
        if (clip != null && clip.streams.isEmpty()) {
            val key = Workspace.key(clip)
            if (Workspace.failures.remove(key) != null) pending[key] = clip
            prioritize(clip); kickMetadata(); refreshSelection()
            return message("Reading available formats. Try Edit again when ready.")
        }
        val current = clip?.let { Workspace.choices[it.index] } ?: Workspace.defaultChoice
        val streams = clip?.streams.orEmpty()
        val showExact = clip != null && streams.isNotEmpty() && (exact || current.videoId != null || current.audioId != null)
        val videos = if (showExact) streams.filter { it.video }.sortedWith(compareByDescending<Stream> { it.height }.thenByDescending { it.fps }) else emptyList()
        val audios = if (clip != null) streams.filter { it.audio && !it.video }.asReversed() else emptyList()
        val panel = column(15)
        fun field(name: String, v: View) { panel.addView(label(name, 12, soft, true), lp(-1, -2, 12)); panel.addView(v, lp(-1, -2, 3)) }
        panel.addView(label(if (clip == null) "Apply one setting to selected videos. You can override each video separately." else clip.title, 14, ink, true))
        val modes = spinner(listOf("Video + audio", "Audio only"), if (current.mode == Mode.VIDEO) 0 else 1); field("DOWNLOAD MODE", modes)
        val standard = listOf(4320, 2160, 1440, 1080, 720, 480, 360, 240, 144)
        val actual = streams.filter { it.video && it.height > 0 }.map { it.height }.distinct().sortedDescending()
        val heights: List<Int?> = listOf(null) + (if (actual.isEmpty()) standard else (actual + listOfNotNull(current.maxHeight)).distinct().sortedDescending())
        val initial = heights.indexOf(current.maxHeight).takeIf { it >= 0 } ?: heights.indexOfFirst { it != null && it <= (current.maxHeight ?: Int.MAX_VALUE) }.coerceAtLeast(0)
        val caps = spinner(heights.map { height ->
            val name = if (height == null) "Best available" else if (actual.isEmpty() || height !in actual) "Up to ${height}p" else "${height}p"
            val estimate = clip?.let { MediaPlanner.plan(it, Choice(maxHeight = height))?.output?.label() ?: "Unavailable" }
            name + (estimate?.let { " · $it" } ?: "")
        }, initial)
        val videoContainer = column(0); videoContainer.addView(label("VIDEO QUALITY LIMIT", 12, soft, true), lp(-1, -2, 10)); videoContainer.addView(caps)
        val video = spinner(listOf("Automatic · quality limit above") + videos.map { it.description() }, (videos.indexOfFirst { it.id == current.videoId } + 1).coerceAtLeast(0))
        if (showExact) { videoContainer.addView(label("EXACT VIDEO STREAM", 12, soft, true), lp(-1, -2, 10)); videoContainer.addView(video) }
        panel.addView(videoContainer)
        val audioContainer = column(0)
        val audio = spinner(listOf("Automatic · best available") + audios.map { it.description() }, (audios.indexOfFirst { it.id == current.audioId } + 1).coerceAtLeast(0))
        if (clip != null) { audioContainer.addView(label("SOURCE AUDIO QUALITY", 12, soft, true), lp(-1, -2, 10)); audioContainer.addView(audio); panel.addView(audioContainer) }
        val audioTypes = AudioType.entries
        val audioType = spinner(audioTypes.map { it.label }, audioTypes.indexOf(current.audioType)); val audioSettings = column(0)
        audioSettings.addView(label("AUDIO OUTPUT", 12, soft, true), lp(-1, -2, 10)); audioSettings.addView(audioType)
        val qualities = listOf("320K", "256K", "192K", "128K", "96K", "64K")
        val mp3 = spinner(qualities.map { q -> q.removeSuffix("K") + " kbps" + (clip?.let { " · " + MediaSizes.byRate(q.removeSuffix("K").toDouble(), it.duration).label() } ?: "") }, qualities.indexOf(current.mp3Quality).coerceAtLeast(0)); val mp3Settings = column(0)
        mp3Settings.addView(label("MP3 TARGET BITRATE", 12, soft, true), lp(-1, -2, 10)); mp3Settings.addView(mp3); audioSettings.addView(mp3Settings); panel.addView(audioSettings)
        val preview = label("", 14, ink, true).apply { setPadding(dp(12), dp(12), dp(12), dp(12)); background = shape(panel2, 8) }
        panel.addView(preview, lp(-1, -2, 12))
        val explanation = label("", 12, soft); panel.addView(explanation, lp(-1, -2, 12))
        val allSelected = checkbox("Replace custom quality for selected videos").apply { isChecked = false }
        if (clip == null) panel.addView(allSelected)
        fun draft(): Choice {
            val mode = if (modes.selectedItemPosition == 0) Mode.VIDEO else Mode.AUDIO
            val stream = if (mode == Mode.VIDEO) videos.getOrNull(video.selectedItemPosition - 1) else null
            val audioId = if (stream?.audio == true || (mode == Mode.VIDEO && !showExact)) null else audios.getOrNull(audio.selectedItemPosition - 1)?.id
            return Choice(mode, heights[caps.selectedItemPosition.coerceAtLeast(0)], audioTypes[audioType.selectedItemPosition.coerceAtLeast(0)], qualities[mp3.selectedItemPosition.coerceAtLeast(0)], stream?.id, audioId, stream?.audio == true)
        }
        fun sync() {
            val videoMode = modes.selectedItemPosition == 0
            val stream = videos.getOrNull(video.selectedItemPosition - 1)
            videoContainer.visibility = if (videoMode) View.VISIBLE else View.GONE
            caps.isEnabled = stream == null
            audioContainer.visibility = if (clip != null && (!videoMode || (showExact && stream?.audio != true))) View.VISIBLE else View.GONE
            audioSettings.visibility = if (videoMode) View.GONE else View.VISIBLE
            mp3Settings.visibility = if (audioTypes[audioType.selectedItemPosition.coerceAtLeast(0)] == AudioType.MP3) View.VISIBLE else View.GONE
            explanation.text = if (videoMode && stream?.audio == true) "This stream already contains audio. Its audio cannot be selected separately." else if (videoMode) "Automatic mode uses the best quality at or below the selected limit. Exact streams are not silently replaced. Container: MP4 or MKV as compatible." else "Conversion cannot improve the original source quality. Original preserves the audio format when possible."
            val choice = draft()
            if (clip != null) {
                val plan = MediaPlanner.plan(Workspace.resolved(clip), choice)
                preview.text = if (plan == null) "${if (Workspace.resolved(clip).streams.isEmpty()) "Reading sizes…" else "Quality not available"}" else {
                    val parts = if (plan.video != null && plan.audio != null) "\nVideo ${MediaSizes.stream(plan.video, clip.duration).label()} + audio ${MediaSizes.stream(plan.audio, clip.duration).label()}" else ""
                    "${plan.qualityLabel()}$parts\nSave: ${plan.output.label()}\nData: ${plan.transfer.label()}"
                }
            } else {
                val items = Workspace.collection?.items.orEmpty().filter { it.available && it.index in Workspace.selection }
                val plans = items.map { Workspace.plans.get(Workspace.resolved(it), if (allSelected.isChecked) choice else Workspace.choices[it.index] ?: choice) }
                preview.text = "Selected · ${items.size}\nSave: ${MediaSizes.total(plans.map { it?.output ?: SizeEstimate() }).label()}\nData: ${MediaSizes.total(plans.map { it?.transfer ?: SizeEstimate() }).label()}"
            }
        }
        modes.onSelect { sync() }; video.onSelect { sync() }; audioType.onSelect { sync() }; caps.onSelect { sync() }; audio.onSelect { sync() }; mp3.onSelect { sync() }; allSelected.setOnCheckedChangeListener { _, _ -> sync() }; sync()
        val scroll = ScrollView(this).apply { addView(panel) }
        val dialog = AlertDialog.Builder(this).setTitle(if (clip == null) "Batch quality" else "Video ${clip.index} · quality").setView(scroll).setNegativeButton("Cancel", null).setPositiveButton("Apply") { _, _ ->
            val choice = draft()
            if (clip == null) {
                Workspace.defaultChoice = choice
                if (allSelected.isChecked) Workspace.selection.forEach { Workspace.choices.remove(it) }
            } else Workspace.choices[clip.index] = choice
            refreshSelection()
        }
        if (clip != null && !showExact) dialog.setNeutralButton(if (streams.isEmpty()) "Load formats" else "Exact formats") { _, _ -> editChoice(clip, true) }
        val sheet = dialog.show()
        qualitySheetRefresh = { sync() }
        sheet.setOnDismissListener { qualitySheetRefresh = null }
        sheet.window?.apply { setGravity(Gravity.BOTTOM); setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT) }
    }
    private fun startDownloads() {
        val collection = Workspace.collection ?: return
        if (busy || QueueStore.running) return
        val items = collection.items.filter { it.available && it.index in Workspace.selection }
        val plans = items.map { Workspace.plan(it) }
        if (plans.any { it == null }) return message("Wait for formats or review unavailable selections.")
        val resolvedPlans = plans.filterNotNull()
        val jobs = items.zip(resolvedPlans).map { (clip, plan) -> Job(Workspace.resolved(clip), plan.choice, Rules.folder(collection.title, collection.playlist), collection.playlist) }
        val output = MediaSizes.total(resolvedPlans.map { it.output })
        val transfer = MediaSizes.total(resolvedPlans.map { it.transfer })
        if (jobs.isEmpty()) return message("Select one or more videos first.")
        AlertDialog.Builder(this).setTitle("Download ${jobs.size} item(s)?").setMessage("Save to ${jobs.first().folder}\n\nEstimated output: ${output.label()}\nData transfer: ${transfer.label()}\n\nOnly save content you own or are authorized to download. Keep enough free storage for temporary streams and the finished file.")
            .setNegativeButton("Cancel", null).setPositiveButton("Start") { _, _ ->
                if (!QueueStore.begin(jobs)) return@setPositiveButton
                try {
                    startForegroundService(Intent(this, DownloadService::class.java)); showTab(1)
                    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 12)
                } catch (e: Exception) { QueueStore.abort(e.message ?: "Could not start service"); errorDialog(e.message ?: "Download service failed") }
            }.show()
    }
    private fun buildQueue() {
        body.addView(label("Downloads", 28, ink, true), lp(-1, -2, 18))
        queueHeader = label("", 14, soft); body.addView(queueHeader!!, lp(-1, -2, 8))
        queueProgress = progressTrack(0, "Batch items processed")
        body.addView(queueProgress!!, lp(-1, 6, 12))
        body.addView(rule(), lp(-1, 1, 18))
        queueAdapter = QueueAdapter()
        val list = ListView(this).apply { adapter = queueAdapter; divider = null; dividerHeight = 0; setPadding(0, dp(4), 0, dp(8)); clipToPadding = false; isVerticalScrollBarEnabled = false }
        body.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        renderQueue()
    }
    private fun renderQueue() {
        val states = QueueStore.states
        val done = states.count { it.phase == Phase.DONE }; val failed = states.count { it.phase == Phase.FAILED }
        val canceled = states.count { it.phase == Phase.CANCELED }
        val processed = TransferProgress.processed(states)
        queueHeader?.text = if (states.isEmpty()) "Nothing queued yet." else "$processed of ${states.size} processed · $done saved" + (if (failed > 0) " · $failed failed" else "") + (if (canceled > 0) " · $canceled canceled" else "") + "\n" + (if (QueueStore.running) "Working in background" else "Batch finished")
        queueProgress?.apply {
            visibility = if (states.isEmpty()) View.GONE else View.VISIBLE
            max = states.size.coerceAtLeast(1); progress = processed
            contentDescription = "$processed of ${states.size} items processed"
        }
        queueAdapter?.notifyDataSetChanged()
        if (queueFooterState != QueueStore.running) {
            queueFooterState = QueueStore.running; footer.removeAllViews()
            if (QueueStore.running) footer.addView(button("Cancel batch") { startService(Intent(this, DownloadService::class.java).setAction(DownloadService.CANCEL)) }, lp(-1, 52))
            else footer.addView(button("Back to library", true) { showTab(0) }, lp(-1, 52))
        }
    }
    private inner class QueueRow : LinearLayout(this@MainActivity) {
        private val thumb = ThumbView()
        private val title = label("", 15, ink, true).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        private val quality = label("", 12, soft)
        private val dynamic = column(0)
        init {
            orientation = VERTICAL; setPadding(0, dp(12), 0, 0)
            val head = row(); head.addView(thumb, lp(88, 50)); head.addView(space(12))
            val info = column(0); info.addView(title); info.addView(quality, lp(-1, -2, 5)); head.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            addView(head); addView(dynamic); addView(rule(), lp(-1, 1, 12))
        }
        fun bind(state: JobState) {
            thumb.bind(state.job.clip); title.text = "${state.job.clip.index.toString().padStart(2, '0')} · ${state.job.clip.title}"
            val plan = MediaPlanner.plan(state.job.clip, state.job.choice)
            quality.text = plan?.let { "${it.qualityLabel()} · ${it.output.label()}" } ?: state.job.choice.summary()
            dynamic.removeAllViews()
            val color = if (state.phase == Phase.FAILED) red else if (state.phase == Phase.DONE) green else soft
            val info = row(); info.addView(label(state.message, 12, color).apply { maxLines = 3 }, LinearLayout.LayoutParams(0, -2, 1f))
            val percentLabel = if (state.phase.active && state.progress != null) "${state.progress}%" else if (state.phase.active) "" else state.phase.name.lowercase().replaceFirstChar { it.uppercase() }
            if (percentLabel.isNotEmpty()) info.addView(label(percentLabel, 12, color, true))
            dynamic.addView(info, lp(-1, -2, 8))
            if (state.phase.active) dynamic.addView(progressTrack(state.progress, "${state.message}${state.progress?.let { ", $it percent" } ?: ""}"), lp(-1, 6, 8))
            if (state.phase == Phase.DOWNLOADING && state.metrics != null) {
                val metrics = state.metrics; val live = row()
                live.addView(label(metrics.speed ?: "Speed unavailable", 12, soft), LinearLayout.LayoutParams(0, -2, 1f))
                live.addView(label(metrics.etaLabel()?.let { "$it left" } ?: "Estimating time…", 12, soft))
                dynamic.addView(live, lp(-1, -2, 8)); metrics.total?.let { dynamic.addView(label("Stream size · $it", 12, soft), lp(-1, -2, 4)) }
            }
            if (state.uri != null) dynamic.addView(button("Open file") { openFile(state.uri) }, lp(-1, -2, 4))
            if (state.phase == Phase.FAILED) dynamic.addView(button("Error details") { errorDialog(state.message) }, lp(-1, -2, 4))
        }
    }
    private inner class QueueAdapter : BaseAdapter() {
        private var snapshot: List<JobState> = QueueStore.states
        override fun notifyDataSetChanged() { snapshot = QueueStore.states; super.notifyDataSetChanged() }
        override fun getCount() = snapshot.size
        override fun getItem(position: Int) = snapshot[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View = (convertView as? QueueRow ?: QueueRow()).apply { bind(getItem(position)) }
    }
    private fun openFile(uriString: String) {
        val uri = Uri.parse(uriString)
        val type = contentResolver.getType(uri) ?: "*/*"
        try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, type).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        catch (_: Exception) { message("Open the saved file in your Files app.") }
    }
    private fun message(text: String) { Toast.makeText(this, text, Toast.LENGTH_LONG).show() }
    private fun errorDialog(text: String) { AlertDialog.Builder(this).setTitle("Could not complete operation").setMessage(text.takeLast(4000)).setNeutralButton("Copy") { _, _ -> getSystemService(ClipboardManager::class.java)!!.setPrimaryClip(ClipData.newPlainText("Nazzelha error", text)) }.setPositiveButton("OK", null).show() }
}
