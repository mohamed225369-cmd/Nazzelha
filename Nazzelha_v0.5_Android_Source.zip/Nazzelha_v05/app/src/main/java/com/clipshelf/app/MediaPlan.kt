package com.clipshelf.app

import java.net.URI
import java.util.Locale

// Null bytes means unknown, never zero. Transfer size and final output are distinct.
data class SizeEstimate(val bytes: Long? = null, val approximate: Boolean = true) {
    fun label(): String = bytes?.let { (if (approximate) "≈ " else "") + MediaSizes.bytes(it) } ?: "Size unknown"
}
data class PlannedMedia(val choice: Choice, val video: Stream?, val audio: Stream?,
                        val output: SizeEstimate, val transfer: SizeEstimate) {
    fun qualityLabel(): String = if (choice.mode == Mode.VIDEO) {
        val v = video!!
        "${if (v.height > 0) "${v.height}p" else "Video"}${if (v.fps > 30) " · ${v.fps}fps" else ""} · " +
            (if (v.audio) "Included audio" else "${audioLabel(audio!!)} audio")
    } else if (choice.audioType == AudioType.MP3) "MP3 · ${choice.mp3Quality.removeSuffix("K")} kbps"
    else "${if (choice.audioType == AudioType.ORIGINAL) audio!!.ext.uppercase(Locale.ROOT) else choice.audioType.label} · ${audioLabel(audio!!)} source"
    companion object {
        fun audioLabel(s: Stream): String {
            val br = MediaSizes.audioRate(s)
            return if (br > 0) "${br.toInt()} kbps" else s.acodec.substringBefore('.').uppercase(Locale.ROOT)
        }
    }
}
data class SizeTotal(val knownBytes: Long, val unknown: Int, val approximate: Boolean, val count: Int) {
    fun label(): String = when {
        count == 0 -> "0 B"
        unknown == count -> "Size pending / unknown"
        else -> (if (approximate || unknown > 0) "≈ " else "") + MediaSizes.bytes(knownBytes) +
            (if (unknown > 0) " + $unknown unknown" else "")
    }
}
object MediaSizes {
    fun bytes(n: Long): String {
        val units = listOf("B", "KiB", "MiB", "GiB", "TiB")
        var v = n.coerceAtLeast(0).toDouble(); var i = 0
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return if (i == 0) "${v.toLong()} B" else String.format(Locale.US, "%.1f %s", v, units[i])
    }
    fun byRate(kbps: Double, seconds: Long): SizeEstimate {
        val bytes = kbps * 1000.0 / 8.0 * seconds
        return if (kbps > 0 && seconds > 0 && bytes.isFinite() && bytes < Long.MAX_VALUE.toDouble()) SizeEstimate(bytes.toLong(), true) else SizeEstimate()
    }
    fun audioRate(s: Stream): Double = s.audioBitrate.takeIf { it.isFinite() && it > 0 } ?: if (s.audio && !s.video) s.bitrate else 0.0
    fun stream(s: Stream, seconds: Long): SizeEstimate = if (s.size > 0) SizeEstimate(s.size, s.sizeApprox)
        else byRate(s.totalBitrate.takeIf { it > 0 } ?: if (s.video && s.audio) 0.0 else s.bitrate, seconds)
    private fun add(a: Long, b: Long): Long = if (Long.MAX_VALUE - a < b) Long.MAX_VALUE else a + b
    fun pair(a: SizeEstimate, b: SizeEstimate, mux: Boolean = false): SizeEstimate =
        if (a.bytes == null || b.bytes == null) SizeEstimate() else SizeEstimate(add(a.bytes, b.bytes), mux || a.approximate || b.approximate)
    fun total(estimates: Iterable<SizeEstimate>): SizeTotal {
        var bytes = 0L; var unknown = 0; var count = 0; var approx = false
        for (e in estimates) { count++; if (e.bytes == null) unknown++ else { bytes = add(bytes, e.bytes); approx = approx || e.approximate } }
        return SizeTotal(bytes, unknown, approx, count)
    }
}
// yt-dlp supplies sorted formats (worst -> best). Preserve its preference order
// within a resolution; automatic audio takes its best ranked audio-only stream.
// Pin the very same IDs at download so preview and execution don't silently diverge.
object MediaPlanner {
    fun plan(clip: Clip, c: Choice): PlannedMedia? {
        val streams = clip.streams
        if (!clip.available || streams.isEmpty()) return null
        val bestAudio = streams.lastOrNull { it.audio && !it.video }
        if (c.mode == Mode.AUDIO) {
            val a = if (c.audioId != null) streams.find { it.id == c.audioId && it.audio } ?: return null
                else bestAudio ?: streams.lastOrNull { it.audio && it.video } ?: return null
            val input = MediaSizes.stream(a, clip.duration)
            val output = when {
                c.audioType == AudioType.ORIGINAL && !a.video -> input
                c.audioType.ext == a.ext && !a.video && c.audioType != AudioType.MP3 -> input
                c.audioType == AudioType.MP3 && a.ext == "mp3" && !a.video -> input
                c.audioType == AudioType.MP3 -> MediaSizes.byRate(c.mp3Quality.removeSuffix("K").toDoubleOrNull() ?: 0.0, clip.duration)
                c.audioType == AudioType.ORIGINAL -> MediaSizes.byRate(MediaSizes.audioRate(a), clip.duration)
                else -> SizeEstimate() // Codec conversion / lossless compression has no known size.
            }
            return PlannedMedia(c.copy(audioId = a.id, audioFromVideo = a.video, videoId = null, combined = false), null, a, output, input)
        }
        val eligible = streams.filter { it.video && (c.maxHeight == null || (it.height in 1..c.maxHeight)) }
        // Combined formats can be chosen explicitly. In automatic mode use a
        // separate video stream plus best audio, falling back only if necessary.
        val v = if (c.videoId != null) streams.find { it.id == c.videoId && it.video } ?: return null
            else eligible.filter { (!it.audio && bestAudio != null) || (it.audio && c.audioId == null) }.let { pool ->
                val height = pool.maxOfOrNull { it.height }
                val sameHeight = pool.filter { it.height == height }
                sameHeight.lastOrNull { !it.audio } ?: sameHeight.lastOrNull()
            } ?: return null
        if (v.audio) {
            if (c.audioId != null) return null
            val size = MediaSizes.stream(v, clip.duration)
            return PlannedMedia(c.copy(videoId = v.id, audioId = null, combined = true), v, null, size, size)
        }
        val a = if (c.audioId != null) streams.find { it.id == c.audioId && it.audio && !it.video } ?: return null else bestAudio ?: return null
        val vs = MediaSizes.stream(v, clip.duration); val asize = MediaSizes.stream(a, clip.duration)
        return PlannedMedia(c.copy(videoId = v.id, audioId = a.id, combined = false), v, a,
            MediaSizes.pair(vs, asize, mux = true), MediaSizes.pair(vs, asize))
    }
}
// One last plan per row; choice changes and metadata replacement invalidate it.
class PlanCache {
    private data class Entry(val clip: Clip, val choice: Choice, val plan: PlannedMedia?)
    private val entries = mutableMapOf<Int, Entry>()
    fun get(clip: Clip, choice: Choice): PlannedMedia? {
        val previous = entries[clip.index]
        if (previous != null && previous.clip.streams === clip.streams && previous.clip.duration == clip.duration && previous.clip.available == clip.available && previous.choice == choice) return previous.plan
        return MediaPlanner.plan(clip, choice).also { entries[clip.index] = Entry(clip, choice, it) }
    }
    fun clear() = entries.clear()
}
object ThumbnailRules {
    private val id = Regex("[A-Za-z0-9_-]{11}")
    fun valid(url: String): Boolean = runCatching {
        val uri = URI(url); val host = uri.host?.lowercase(Locale.ROOT) ?: return@runCatching false
        uri.scheme == "https" && uri.userInfo == null && (uri.port == -1 || uri.port == 443) &&
            (host == "ytimg.com" || host.endsWith(".ytimg.com") || host.endsWith(".ggpht.com"))
    }.getOrDefault(false)
    fun fallback(videoId: String): String = if (id.matches(videoId)) "https://i.ytimg.com/vi/$videoId/mqdefault.jpg" else ""
    fun pick(videoId: String, candidates: List<Pair<String, Int>>, direct: String): String =
        candidates.filter { valid(it.first) && it.second > 0 }.minByOrNull { kotlin.math.abs(it.second - 320) }?.first
            ?: fallback(videoId).ifBlank { direct.takeIf(::valid) ?: candidates.firstOrNull { valid(it.first) }?.first.orEmpty() }
}
