package com.clipshelf.app

import java.net.URI
import java.util.UUID

enum class Mode { VIDEO, AUDIO }
enum class AudioType(val label: String, val ext: String?) {
    ORIGINAL("Original (no conversion)", null), MP3("MP3", "mp3"), M4A("M4A", "m4a"), OPUS("Opus", "opus"), FLAC("FLAC", "flac")
}
data class Stream(val id: String, val ext: String, val width: Int, val height: Int, val fps: Int,
                  val vcodec: String, val acodec: String, val bitrate: Double, val size: Long, val note: String,
                  val sizeApprox: Boolean = false, val audioBitrate: Double = 0.0, val totalBitrate: Double = 0.0) {
    val video get() = vcodec.isNotBlank() && vcodec != "none" && vcodec != "unknown"
    val audio get() = acodec.isNotBlank() && acodec != "none" && acodec != "unknown"
    fun description(): String {
        val quality = if (video) "${if (height > 0) "${height}p" else "Video"}${if (fps > 0) " / ${fps}fps" else ""}" else "${if (bitrate > 0) "${bitrate.toInt()} kbps" else "Audio"}"
        val codec = listOf(vcodec.takeIf { video }, acodec.takeIf { audio }).filterNotNull().joinToString(" + ")
        val bytes = if (size > 0) " · ${if (sizeApprox) "≈ " else ""}${MediaSizes.bytes(size)}" else ""
        return "$quality · $ext · $codec${if (video && audio) " · combined" else ""}$bytes · #$id${if (note.isNotBlank()) " · $note" else ""}"
    }
}
data class Choice(val mode: Mode = Mode.VIDEO, val maxHeight: Int? = 1080,
                  val audioType: AudioType = AudioType.ORIGINAL, val mp3Quality: String = "192K",
                  val videoId: String? = null, val audioId: String? = null, val combined: Boolean = false, val audioFromVideo: Boolean = false) {
    fun summary(): String = if (mode == Mode.VIDEO) {
        (videoId?.let { "Video #$it" } ?: maxHeight?.let { "Up to ${it}p" } ?: "Best video") +
            if (combined) " · Combined audio" else " · " + (audioId?.let { "Audio #$it" } ?: "Best audio")
    } else "${audioType.label}" + (if (audioType == AudioType.MP3) " · $mp3Quality" else "") + (audioId?.let { " · #$it" } ?: " · Best source")
}
data class Clip(val index: Int, val id: String, val title: String, val url: String, val duration: Long = 0,
                val thumbnail: String = "", val available: Boolean = true, val streams: List<Stream> = emptyList())
data class Collection(val title: String, val playlist: Boolean, val items: List<Clip>)
data class Job(val clip: Clip, val choice: Choice, val folder: String, val playlist: Boolean, val key: String = UUID.randomUUID().toString())
enum class Phase {
    WAITING, DOWNLOADING, PROCESSING, SAVING, DONE, FAILED, CANCELED;
    val active get() = this in setOf(DOWNLOADING, PROCESSING, SAVING)
    val terminal get() = this in setOf(DONE, FAILED, CANCELED)
}
data class TransferMetrics(val speed: String? = null, val etaSeconds: Long? = null, val total: String? = null) {
    fun etaLabel(): String? = etaSeconds?.takeIf { it >= 0 }?.let {
        when {
            it >= 3600 -> "%dh %02dm".format(it / 3600, (it / 60) % 60)
            it >= 60 -> "%dm %02ds".format(it / 60, it % 60)
            else -> "${it}s"
        }
    }
    fun summary(): String = listOfNotNull(speed, etaLabel()?.let { "$it left" }, total?.let { "$it stream" }).joinToString(" · ")
}
data class JobState(val job: Job, val phase: Phase = Phase.WAITING, val progress: Int? = null, val message: String = "Queued", val uri: String? = null, val metrics: TransferMetrics? = null)
data class TransferUpdate(val phase: Phase, val percent: Int?, val message: String, val metrics: TransferMetrics? = null)
object TransferProgress {
    private val speedPattern = Regex("""\bat\s+(\d+(?:\.\d+)?\s*[KMGT]?i?B/s)\b""", RegexOption.IGNORE_CASE)
    private val sizePattern = Regex("""\bof\s+(~?\s*\d+(?:\.\d+)?\s*[KMGT]?i?B)\b""", RegexOption.IGNORE_CASE)
    private val etaPattern = Regex("""\bETA\s+(\d+:\d{2}(?::\d{2})?)\b""")
    private fun lineEta(text: String): Long? {
        val pieces = etaPattern.find(text)?.groupValues?.get(1)?.split(':') ?: return null
        return pieces.fold(0L) { total, part -> total * 60 + (part.toLongOrNull() ?: return null) }
    }
    // yt-dlp percentages, rate and ETA describe the current stream, not the entire output or playlist.
    fun fromCallback(percent: Float, eta: Long, line: String): TransferUpdate? {
        val text = line.trimStart()
        if (listOf("[Merger]", "[ExtractAudio]", "[VideoConvertor]", "[VideoRemuxer]", "[Fixup").any { text.startsWith(it) })
            return TransferUpdate(Phase.PROCESSING, null, "Processing media with FFmpeg")
        if (!percent.isFinite() || percent < 0f) return null
        if (percent >= 100f) return TransferUpdate(Phase.DOWNLOADING, null, "Stream received")
        val rate = speedPattern.find(text)?.groupValues?.get(1)?.replace(Regex("""\s+"""), " ")
        val total = sizePattern.find(text)?.groupValues?.get(1)?.trim()?.replace(Regex("""\s+"""), " ")
        // Explicit unknown ETA must not be turned into a false countdown.
        val remaining = lineEta(text) ?: eta.takeIf { it >= 0 && !text.contains("ETA Unknown", ignoreCase = true) }
        val metrics = TransferMetrics(rate, remaining, total)
        return TransferUpdate(Phase.DOWNLOADING, percent.toInt().coerceIn(0, 99), "Downloading stream", metrics)
    }
    fun saving(copied: Long, total: Long): TransferUpdate = TransferUpdate(Phase.SAVING,
        if (total > 0) (copied.toDouble() / total * 100).toInt().coerceIn(0, 99) else null,
        "Saving to Downloads")
    fun processed(states: List<JobState>): Int = states.count { it.phase.terminal }
}

object Rules {
    private val validId = Regex("[A-Za-z0-9_.-]+")
    fun selector(c: Choice): String {
        require(c.videoId == null || validId.matches(c.videoId)) { "Invalid video format ID" }
        require(c.audioId == null || validId.matches(c.audioId)) { "Invalid audio format ID" }
        if (c.mode == Mode.AUDIO) return c.audioId ?: "bestaudio/best"
        val audio = c.audioId ?: "bestaudio"
        if (c.videoId != null) return if (c.combined) c.videoId else "${c.videoId}+$audio"
        val cap = c.maxHeight?.let { "[height<=$it]" } ?: ""
        // Explicit audio selection cannot silently fall back to a combined stream.
        return if (c.audioId != null) "bestvideo$cap+$audio" else "bestvideo$cap+bestaudio/best$cap"
    }
    fun formatOptions(c: Choice): List<Pair<String, String?>> = buildList {
        add("-f" to selector(c))
        if (c.mode == Mode.VIDEO) add("--merge-output-format" to "mp4/mkv")
        else if (c.audioType.ext != null) {
            add("--extract-audio" to null)
            add("--audio-format" to c.audioType.ext)
            if (c.audioType == AudioType.MP3) add("--audio-quality" to c.mp3Quality)
        } else if (c.audioId == null || c.audioFromVideo) {
            // Best can fall back to a combined stream; extract its audio in that case.
            add("--extract-audio" to null)
            add("--audio-format" to "best")
        }
    }
    fun safeName(raw: String, fallback: String, limit: Int = 100): String {
        val clean = raw.replace(Regex("[\\p{Cc}\\p{Cf}\\\\/:*?\"<>|]"), "_").replace(Regex("\\s+"), " ").trim(' ', '.')
        // UTF-8 byte limit protects Android filesystem names even for multibyte titles.
        val sb = StringBuilder(); var bytes = 0
        val maxBytes = limit.coerceAtLeast(8)
        val iter = clean.codePoints().iterator()
        while (iter.hasNext()) {
            val part = String(Character.toChars(iter.nextInt()))
            val count = part.toByteArray(Charsets.UTF_8).size
            if (bytes + count > maxBytes) break
            sb.append(part); bytes += count
        }
        return sb.toString().trim(' ', '.').ifBlank { fallback }
    }
    fun folder(title: String, playlist: Boolean) = "Download/Nazzelha/" + if (playlist) safeName(title, "Playlist") + "/" else ""
    fun fileName(job: Job, ext: String): String {
        val prefix = if (job.playlist) "${job.clip.index.toString().padStart(3, '0')} - " else ""
        val title = safeName(job.clip.title, job.clip.id.ifBlank { "Video" }, 145)
        val id = safeName(job.clip.id, "video", 32)
        return "$prefix$title [$id].${safeName(ext.lowercase(), "bin", 10)}"
    }
    fun youtubeLink(text: String): String? {
        val candidate = Regex("https?://[^\\s<>]+", RegexOption.IGNORE_CASE).find(text.trim())?.value?.trimEnd('.', ',', ')', ']', '"', '\'') ?: return null
        val uri = runCatching { URI(candidate) }.getOrNull() ?: return null
        val host = uri.host?.lowercase() ?: return null
        if (uri.scheme?.lowercase() !in setOf("http", "https") || uri.userInfo != null || (uri.port != -1 && uri.port !in listOf(80, 443))) return null
        if (host !in setOf("youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtu.be")) return null
        return candidate.replaceFirst(Regex("^http:", RegexOption.IGNORE_CASE), "https:")
    }
    fun duration(seconds: Long): String = if (seconds <= 0) "—" else if (seconds >= 3600) "%d:%02d:%02d".format(seconds / 3600, (seconds / 60) % 60, seconds % 60) else "%d:%02d".format(seconds / 60, seconds % 60)
}
